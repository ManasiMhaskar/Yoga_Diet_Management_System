// ============================================
// YOGA DIET WITH MANASI - MAIN APPLICATION
// ============================================

// ============================================
// PARTICLES
// ============================================
(function createParticles() {
    const container = document.getElementById('particles');
    if (!container) return;
    for (let i = 0; i < 30; i++) {
        const p = document.createElement('div');
        p.classList.add('particle');
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (15 + Math.random() * 20) + 's';
        p.style.animationDelay = (Math.random() * 15) + 's';
        p.style.width = (2 + Math.random() * 4) + 'px';
        p.style.height = p.style.width;
        p.style.opacity = 0.1 + Math.random() * 0.3;
        container.appendChild(p);
    }
})();

// ============================================
// AI POPUP
// ============================================
function openAIPopup() {
    document.getElementById('aiPopup').classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeAIPopup() {
    document.getElementById('aiPopup').classList.remove('show');
    document.body.style.overflow = 'auto';
}

// Close popup with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAIPopup();
    }
});

// Close popup clicking outside content
document.addEventListener('click', function(e) {
    const popup = document.getElementById('aiPopup');
    if (e.target === popup) {
        closeAIPopup();
    }
});

// ============================================
// THEME TOGGLE
// ============================================
let darkMode = true;

function toggleTheme() {
    darkMode = !darkMode;
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
    const icon = document.getElementById('themeIcon');
    if (icon) {
        icon.className = darkMode ? 'fas fa-moon' : 'fas fa-sun';
    }
    localStorage.setItem('theme', darkMode ? 'dark' : 'light');
}

const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') {
    darkMode = false;
    document.documentElement.setAttribute('data-theme', 'light');
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = 'fas fa-sun';
}

// ============================================
// SCROLL TO SECTION
// ============================================
function scrollToSection(id) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ============================================
// NAVBAR SCROLL EFFECT
// ============================================
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
    if (navbar) {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    }
});

// ============================================
// TOAST NOTIFICATION
// ============================================
function showToast(message) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.5s';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// ============================================
// FEATURE CARD CLICK
// ============================================
function handleFeatureClick(feature) {
    const map = {
        'yoga': 'assessment',
        'diet': 'assessment',
        'dashboard': 'dashboard',
        'charts': 'charts',
        'journal': 'journal',
        'achievements': 'achievements'
    };
    const target = map[feature] || 'home';
    const section = document.getElementById(target);
    if (section) {
        section.classList.add('show');
        setTimeout(() => scrollToSection(target), 200);
    }
    showToast(`✨ Exploring: ${feature.charAt(0).toUpperCase() + feature.slice(1)}`);
}

// ============================================
// AUTH SYSTEM
// ============================================
let isLogin = true;
let currentOTP = '';

function openAuth() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        showLogin();
    }
}

function closeAuth() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }
}

function showLogin() {
    const ids = ['loginForm', 'forgotPasswordForm', 'otpForm', 'resetPasswordForm', 'successMessage'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = id === 'loginForm' ? 'block' : 'none';
    });
}

function showForgotPassword() {
    const ids = ['loginForm', 'forgotPasswordForm', 'otpForm', 'resetPasswordForm', 'successMessage'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = id === 'forgotPasswordForm' ? 'block' : 'none';
    });
}

function showOTPForm() {
    const ids = ['loginForm', 'forgotPasswordForm', 'otpForm', 'resetPasswordForm', 'successMessage'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = id === 'otpForm' ? 'block' : 'none';
    });
    document.querySelectorAll('.otp-input').forEach(i => i.value = '');
    const firstInput = document.querySelector('.otp-input');
    if (firstInput) firstInput.focus();
}

function showResetPassword() {
    const ids = ['loginForm', 'forgotPasswordForm', 'otpForm', 'resetPasswordForm', 'successMessage'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = id === 'resetPasswordForm' ? 'block' : 'none';
    });
}

function toggleAuth() {
    isLogin = !isLogin;
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;
    
    const h2 = loginForm.querySelector('h2');
    const p = loginForm.querySelector('p');
    const btn = loginForm.querySelector('#authForm .auth-btn');
    const switchEl = loginForm.querySelector('.auth-switch');
    
    if (h2) h2.textContent = isLogin ? 'Welcome Back' : 'Join the Community';
    if (p) p.textContent = isLogin ? 'Sign in to track your wellness journey' : 'Create your account and start your journey';
    if (btn) btn.textContent = isLogin ? 'Sign In' : 'Create Account';
    if (switchEl) {
        switchEl.innerHTML = isLogin ? 
            "Don't have an account? <span>Sign up</span>" : 
            "Already have an account? <span>Sign in</span>";
    }
    showLogin();
}

// OTP Functions
function otpInput(input) {
    input.value = input.value.replace(/[^0-9]/g, '');
    if (input.value.length === 1) {
        const next = input.nextElementSibling;
        if (next && next.classList.contains('otp-input')) next.focus();
    }
}

function otpKeydown(event, input) {
    if (event.key === 'Backspace' && !input.value) {
        const prev = input.previousElementSibling;
        if (prev && prev.classList.contains('otp-input')) prev.focus();
    }
    if (event.key === 'Enter') verifyOTP();
}

function getOTP() {
    let otp = '';
    document.querySelectorAll('.otp-input').forEach(i => otp += i.value);
    return otp;
}

function checkPasswordStrength(password) {
    const bar = document.getElementById('resetStrengthBar');
    if (!bar) return;
    if (!password) { bar.className = 'strength-bar'; return; }
    let s = 0;
    if (password.length >= 8) s++;
    if (/[a-z]/.test(password)) s++;
    if (/[A-Z]/.test(password)) s++;
    if (/[0-9]/.test(password)) s++;
    if (/[^a-zA-Z0-9]/.test(password)) s++;
    bar.className = s <= 2 ? 'strength-bar weak' : s <= 3 ? 'strength-bar medium' : 'strength-bar strong';
}

// Forgot Password
const forgotForm = document.getElementById('forgotPasswordFormElement');
if (forgotForm) {
    forgotForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('resetEmail').value;
        if (email) {
            currentOTP = String(Math.floor(100000 + Math.random() * 900000));
            console.log('📧 OTP for ' + email + ': ' + currentOTP);
            showToast('📧 OTP sent to ' + email + ' (Check console)');
            showOTPForm();
        }
    });
}

function verifyOTP() {
    if (getOTP().length !== 6) { 
        showToast('⚠️ Please enter all 6 digits'); 
        return; 
    }
    if (getOTP() === currentOTP) {
        showToast('✅ OTP verified!');
        showResetPassword();
    } else {
        showToast('❌ Invalid OTP');
        document.querySelectorAll('.otp-input').forEach(i => i.value = '');
        const firstInput = document.querySelector('.otp-input');
        if (firstInput) firstInput.focus();
    }
}

const resetForm = document.getElementById('resetPasswordFormElement');
if (resetForm) {
    resetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const np = document.getElementById('newPassword').value;
        const cp = document.getElementById('confirmPassword').value;
        if (np.length < 8) { 
            showToast('⚠️ Password must be 8+ characters'); 
            return; 
        }
        if (np !== cp) { 
            showToast('⚠️ Passwords do not match'); 
            return; 
        }
        localStorage.setItem('userPassword', np);
        const successText = document.getElementById('successText');
        if (successText) successText.textContent = '✅ Your password has been reset successfully!';
        const ids = ['loginForm', 'forgotPasswordForm', 'otpForm', 'resetPasswordForm', 'successMessage'];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = id === 'successMessage' ? 'block' : 'none';
        });
        setTimeout(() => { 
            showLogin(); 
            showToast('✅ Password updated!'); 
        }, 2000);
    });
}

// Login
const authForm = document.getElementById('authForm');
if (authForm) {
    authForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('authEmail').value;
        const pass = document.getElementById('authPassword').value;
        if (email && pass) {
            const saved = localStorage.getItem('userPassword');
            if (saved && pass !== saved) { 
                showToast('❌ Invalid password'); 
                return; 
            }
            localStorage.setItem('userEmail', email);
            localStorage.setItem('isLoggedIn', 'true');
            if (!saved) localStorage.setItem('userPassword', pass);
            showToast('✅ Signed in!');
            closeAuth();
            updateAuthButton(email);
        }
    });
}

function updateAuthButton(email) {
    const btn = document.getElementById('authBtn');
    if (!btn) return;
    btn.innerHTML = '<i class="fas fa-user-check"></i> ' + email.split('@')[0];
    btn.onclick = function() {
        if (confirm('Logout?')) {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('userEmail');
            location.reload();
        }
    };
}

if (localStorage.getItem('isLoggedIn') === 'true') {
    const email = localStorage.getItem('userEmail') || 'User';
    updateAuthButton(email);
}

// ============================================
// ASSESSMENT FORM
// ============================================
const form = document.getElementById('userForm');
const resultsSection = document.getElementById('results');
const resultsContainer = document.getElementById('results-container');

if (form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (resultsSection) resultsSection.classList.add('show');
        if (resultsContainer) {
            resultsContainer.innerHTML = `<div class="spinner-container"><div class="spinner"></div><div class="spinner-text">✨ Crafting your plan...</div></div>`;
        }

        const userData = {
            name: document.getElementById('name').value.trim(),
            age: parseInt(document.getElementById('age').value),
            weight: parseFloat(document.getElementById('weight').value),
            height: parseFloat(document.getElementById('height').value),
            goal: document.getElementById('goal').value,
            experience: document.getElementById('experience').value,
            diet: document.getElementById('diet').value
        };

        if (!userData.name || !userData.age || !userData.weight || !userData.height || !userData.goal || !userData.experience || !userData.diet) {
            if (resultsContainer) {
                resultsContainer.innerHTML = `<div class="result-card full-width" style="text-align:center;border-color:rgba(239,68,68,0.3);">
                    <i class="fas fa-exclamation-circle" style="font-size:3rem;color:#EF4444;margin-bottom:1rem;"></i>
                    <h3 style="color:#EF4444;">Please fill all fields</h3>
                </div>`;
            }
            return;
        }

        localStorage.setItem('userData', JSON.stringify(userData));

        setTimeout(() => {
            try {
                const recs = generateRecommendations(userData);
                displayResults(recs, userData);
                updateDashboard(userData, recs);
                updateCharts(userData);
                updateAchievements(userData, recs);
                showToast('🎉 Your plan is ready!');
                if (resultsSection) resultsSection.scrollIntoView({ behavior: 'smooth' });
                
                const sections = ['dashboard', 'charts', 'journal', 'reminders', 'achievements'];
                sections.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.classList.add('show');
                });
            } catch (error) {
                console.error(error);
                if (resultsContainer) {
                    resultsContainer.innerHTML = `<div class="result-card full-width" style="text-align:center;border-color:rgba(239,68,68,0.3);">
                        <i class="fas fa-exclamation-triangle" style="font-size:3rem;color:#FB923C;margin-bottom:1rem;"></i>
                        <h3 style="color:#FB923C;">Something went wrong</h3>
                    </div>`;
                }
            }
        }, 1500);
    });
}

// ============================================
// RECOMMENDATION ENGINE (AI-Powered)
// ============================================
function generateRecommendations(user) {
    const bmi = user.weight / (user.height * user.height);
    let bmiCategory = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal weight' : bmi < 30 ? 'Overweight' : 'Obese';
    let bmr = 88.362 + (13.397 * user.weight) + (4.799 * (user.height * 100)) - (5.677 * user.age);
    let dailyCalories = Math.round(bmr * 1.2);
    if (user.goal === 'weight_loss') dailyCalories -= 300;
    else if (user.goal === 'muscle_gain') dailyCalories += 300;

    const yogaRoutine = getYogaRoutine(user.goal, user.experience);
    const dietPlan = getDietPlan(user.diet, user.goal);
    return { bmi, bmiCategory, dailyCalories, yogaRoutine, dietPlan };
}

function getYogaRoutine(goal, exp) {
    const routines = {
        weight_loss: ['🌅 Surya Namaskar - 12 rounds', '🪑 Chair Pose - Hold 30s, 3 reps', '⚔️ Warrior Pose - 3 reps each side', '🚣 Boat Pose - Hold 30s, 3 reps', '📋 Plank Pose - Hold 45s, 3 reps'],
        muscle_gain: ['🪑 Chair Pose - Hold 1min, 5 reps', '⚔️ Warrior III - Hold 30s each side', '🚣 Boat Pose - Hold 45s, 5 reps', '🐦 Crow Pose - 3 times', '📋 Side Plank - Hold 30s each side'],
        flexibility: ['🐕 Downward Dog - Hold 1min', '🕊️ Pigeon Pose - Hold 1min each side', '🧘 Forward Fold - Hold 1min', '🦋 Butterfly Pose - Hold 1min', '🐍 Cobra Pose - Hold 30s, 5 reps'],
        stress_relief: ['🧒 Child\'s Pose - 2 mins', '🐱 Cat-Cow Stretch - 10 breaths', '🧘 Legs Up the Wall - 5 mins', '😴 Savasana - 5 mins', '🌬️ Alternate Nostril Breathing - 5 mins']
    };
    let r = routines[goal] || routines.stress_relief;
    if (exp === 'beginner') r = r.map(x => x + ' (Shorter holds)');
    else if (exp === 'advanced') r.push('🔥 Add arm balances & inversions');
    return r;
}

function getDietPlan(pref, goal) {
    const plans = {
        weight_loss: {
            vegetarian: { breakfast: ['🥣 Oatmeal with berries', '🥤 Green smoothie'], lunch: ['🥣 Lentil soup', '🥗 Quinoa salad'], dinner: ['🥩 Grilled tofu', '🥘 Veg stir-fry'], snacks: ['🍎 Apple with PB', '🥜 Almonds'] },
            'non-vegetarian': { breakfast: ['🍳 Scrambled eggs', '🥛 Greek yogurt'], lunch: ['🥗 Grilled chicken salad', '🥪 Tuna sandwich'], dinner: ['🐟 Steamed fish', '🍗 Turkey breast'], snacks: ['🥚 Hard-boiled eggs', '🥤 Protein shake'] }
        },
        muscle_gain: {
            vegetarian: { breakfast: ['🥤 Protein smoothie', '🍳 Tofu scramble'], lunch: ['🥗 Chickpea bowl', '🍔 Lentil burger'], dinner: ['🧀 Paneer tikka', '🥘 Tempeh stir-fry'], snacks: ['🥜 Trail mix', '🥤 Protein shake'] },
            'non-vegetarian': { breakfast: ['🍳 Egg white omelette', '🥞 Protein pancakes'], lunch: ['🍗 Chicken breast', '🐟 Salmon'], dinner: ['🥩 Steak', '🍝 Turkey meatballs'], snacks: ['🥛 Greek yogurt', '🍫 Protein bar'] }
        }
    };
    let defaultPlan = { breakfast: ['🥣 Fresh fruits', '🍞 Avocado toast'], lunch: ['🥗 Mediterranean salad', '🥘 Veg curry'], dinner: ['🥗 Grilled veg', '🍝 Zucchini pasta'], snacks: ['🥕 Veg sticks', '🥤 Fruit smoothie'] };
    let gp = plans[goal];
    if (!gp) return defaultPlan;
    let pp = gp[pref] || gp['vegetarian'] || defaultPlan;
    return pp;
}

// ============================================
// DISPLAY RESULTS
// ============================================
function displayResults(data, user) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    const bmiClass = data.bmiCategory === 'Normal weight' ? 'success' : data.bmiCategory === 'Underweight' ? 'info' : data.bmiCategory === 'Overweight' ? 'warning' : 'danger';
    container.innerHTML = `
        <div class="result-card full-width user-summary">
            <h3><i class="fas fa-user-circle"></i> Welcome, ${user.name}!</h3>
            <div class="stat-grid">
                <div class="stat"><div class="value">${user.age} yrs</div><div class="label">Age</div></div>
                <div class="stat"><div class="value">${user.weight} kg</div><div class="label">Weight</div></div>
                <div class="stat"><div class="value">${user.height} m</div><div class="label">Height</div></div>
                <div class="stat"><div class="value">🎯 ${user.goal.replace('_', ' ')}</div><div class="label">Goal</div></div>
                <div class="stat"><div class="value">${user.experience}</div><div class="label">Experience</div></div>
                <div class="stat"><div class="value">${user.diet}</div><div class="label">Diet</div></div>
            </div>
            <div style="margin-top:1.5rem;padding-top:1.5rem;border-top:1px solid var(--border-color);display:flex;gap:2rem;flex-wrap:wrap;">
                <div><span style="color:var(--text-secondary);">BMI</span><br><span style="font-size:1.5rem;font-weight:700;">${data.bmi.toFixed(1)}</span> <span class="bmi-badge ${bmiClass}">${data.bmiCategory}</span></div>
                <div><span style="color:var(--text-secondary);">Daily Calories</span><br><span class="calories-display">🔥 ${data.dailyCalories} kcal</span></div>
            </div>
        </div>
        <div class="result-card"><h3><i class="fas fa-yoga"></i> Yoga Routine</h3><ul>${data.yogaRoutine.map(p => `<li><i class="fas fa-check-circle"></i> ${p}</li>`).join('')}</ul></div>
        <div class="result-card"><h3><i class="fas fa-utensils"></i> Diet Plan</h3>
            ${Object.entries(data.dietPlan).map(([meal, items]) => `
                <div class="meal-section"><h4><i class="fas fa-${meal === 'breakfast' ? 'sun' : meal === 'lunch' ? 'cloud-sun' : meal === 'dinner' ? 'moon' : 'apple-alt'}"></i> ${meal}</h4>
                <ul>${items.map(item => `<li><i class="fas fa-seedling"></i> ${item}</li>`).join('')}</ul></div>
            `).join('')}
            <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                <h4 style="font-size:0.85rem;color:var(--text-secondary);">⏰ Meal Timings</h4>
                <ul><li><i class="fas fa-clock"></i> Breakfast: 7:00-8:00 AM</li><li><i class="fas fa-clock"></i> Lunch: 12:30-1:30 PM</li><li><i class="fas fa-clock"></i> Dinner: 7:00-8:00 PM</li><li><i class="fas fa-clock"></i> Snacks: 10:30 AM & 4:00 PM</li></ul>
            </div>
        </div>
        <div class="result-card full-width wellness-tips">
            <h3><i class="fas fa-heart" style="color:#F472B6;"></i> Wellness Tips</h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
                <ul><li><i class="fas fa-droplet"></i> Drink 8+ glasses of water daily</li><li><i class="fas fa-moon"></i> 7-8 hours of quality sleep</li><li><i class="fas fa-walking"></i> Daily mindfulness practice</li></ul>
                <ul><li><i class="fas fa-clock"></i> Eat meals at consistent times</li><li><i class="fas fa-book"></i> Listen to your body's signals</li><li><i class="fas fa-heartbeat"></i> Track your progress weekly</li></ul>
            </div>
        </div>
    `;
}

// ============================================
// DASHBOARD UPDATE
// ============================================
function updateDashboard(user, data) {
    const dashWeight = document.getElementById('dashWeight');
    const dashBMI = document.getElementById('dashBMI');
    const dashBMICategory = document.getElementById('dashBMICategory');
    const dashCalories = document.getElementById('dashCalories');
    const dashStreak = document.getElementById('dashStreak');
    const weeklyProgress = document.getElementById('weeklyProgress');
    const progressCircle = document.getElementById('progressCircle');
    
    if (dashWeight) dashWeight.textContent = user.weight + ' kg';
    if (dashBMI) dashBMI.textContent = data.bmi.toFixed(1);
    if (dashBMICategory) dashBMICategory.textContent = data.bmiCategory;
    if (dashCalories) dashCalories.textContent = data.dailyCalories + ' kcal';

    let streak = parseInt(localStorage.getItem('streak') || '0');
    const lastLogin = localStorage.getItem('lastLogin');
    const today = new Date().toDateString();
    if (lastLogin !== today) {
        if (lastLogin && new Date(lastLogin).getTime() === new Date(Date.now() - 86400000).getTime()) streak++;
        else if (lastLogin !== today) streak = 1;
        localStorage.setItem('streak', streak);
        localStorage.setItem('lastLogin', today);
    }
    if (dashStreak) dashStreak.textContent = streak + ' days';
    
    const progress = Math.min(100, (streak / 7) * 100);
    if (weeklyProgress) weeklyProgress.textContent = Math.round(progress) + '%';
    if (progressCircle) {
        progressCircle.setAttribute('stroke-dasharray', (progress / 100) * 314 + ', 314');
    }
}

// ============================================
// CHARTS
// ============================================
function updateCharts(user) {
    const weightChart = document.getElementById('weightChart');
    const bmiChart = document.getElementById('bmiChart');
    
    if (!weightChart || !bmiChart) return;
    
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const baseWeight = user.weight || 70;
    const baseHeight = user.height || 1.75;
    
    const weightData = days.map((_, i) => {
        const variation = (Math.random() - 0.5) * 1.2;
        return Math.round((baseWeight + variation) * 10) / 10;
    });

    const bmiData = weightData.map(w => {
        return Math.round((w / (baseHeight * baseHeight)) * 10) / 10;
    });

    const maxWeight = Math.max(...weightData) + 1.5;
    const minWeight = Math.min(...weightData) - 1.5;
    const maxBMI = Math.max(...bmiData) + 0.5;
    const minBMI = Math.min(...bmiData) - 0.5;

    weightChart.innerHTML = days.map((day, i) => {
        const heightPercent = ((weightData[i] - minWeight) / (maxWeight - minWeight)) * 170 + 10;
        return `
            <div class="chart-bar">
                <div class="bar-value">${weightData[i]}kg</div>
                <div class="bar" style="height: ${Math.max(heightPercent, 15)}%; background: var(--gradient-1);"></div>
                <div class="bar-label">${day}</div>
            </div>
        `;
    }).join('');

    bmiChart.innerHTML = days.map((day, i) => {
        const heightPercent = ((bmiData[i] - minBMI) / (maxBMI - minBMI)) * 170 + 10;
        return `
            <div class="chart-bar">
                <div class="bar-value">${bmiData[i]}</div>
                <div class="bar" style="height: ${Math.max(heightPercent, 15)}%; background: var(--gradient-2);"></div>
                <div class="bar-label">${day}</div>
            </div>
        `;
    }).join('');
}

// ============================================
// ACHIEVEMENTS
// ============================================
function updateAchievements(user, data) {
    const grid = document.getElementById('achievementsGrid');
    if (!grid) return;
    
    const streak = parseInt(localStorage.getItem('streak') || '0');
    const hasAssessment = user.name && user.weight && user.height;
    
    const achievements = [
        { icon: '🌟', name: 'First Step', desc: 'Complete your first assessment', unlocked: hasAssessment },
        { icon: '🧘', name: 'Yoga Beginner', desc: 'Complete 3+ days of practice', unlocked: streak >= 3 },
        { icon: '🥗', name: 'Healthy Eater', desc: 'Follow diet plan for 5+ days', unlocked: streak >= 5 },
        { icon: '🔥', name: 'Streak Master', desc: '7-day wellness streak', unlocked: streak >= 7 },
        { icon: '💪', name: 'Fitness Warrior', desc: '10+ days of consistency', unlocked: streak >= 10 },
        { icon: '🏆', name: 'Wellness Champion', desc: '30 days of dedication', unlocked: streak >= 30 }
    ];

    grid.innerHTML = achievements.map(a => `
        <div class="achievement-card ${a.unlocked ? '' : 'locked'}">
            <div class="achievement-icon">${a.icon}</div>
            <div class="achievement-name">${a.name}</div>
            <div class="achievement-desc">${a.desc}</div>
            <div class="unlock-badge">
                ${a.unlocked ? '✅ Unlocked' : '🔒 Locked'}
            </div>
        </div>
    `).join('');
}

// ============================================
// EDIT MODAL
// ============================================
function openEditModal(field) {
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    const modal = document.createElement('div');
    modal.className = 'auth-modal show';
    modal.id = 'editModal';
    modal.innerHTML = `
        <div class="auth-modal-content" style="max-width:500px;">
            <button class="auth-close" onclick="document.getElementById('editModal').remove()">✕</button>
            <h2>Edit ${field.charAt(0).toUpperCase() + field.slice(1)}</h2>
            <p>Update your information</p>
            <form id="editForm">
                <div class="form-group"><label><i class="fas fa-user"></i> Name</label><input type="text" class="auth-input" id="editName" value="${userData.name || ''}" required></div>
                <div class="form-group"><label><i class="fas fa-weight"></i> Weight (kg)</label><input type="number" class="auth-input" id="editWeight" value="${userData.weight || ''}" step="0.1" required></div>
                <div class="form-group"><label><i class="fas fa-ruler-vertical"></i> Height (m)</label><input type="number" class="auth-input" id="editHeight" value="${userData.height || ''}" step="0.01" required></div>
                <div class="form-group"><label><i class="fas fa-bullseye"></i> Goal</label>
                    <select class="auth-input" id="editGoal">
                        <option value="weight_loss" ${userData.goal === 'weight_loss' ? 'selected' : ''}>Weight Loss</option>
                        <option value="muscle_gain" ${userData.goal === 'muscle_gain' ? 'selected' : ''}>Muscle Gain</option>
                        <option value="flexibility" ${userData.goal === 'flexibility' ? 'selected' : ''}>Flexibility</option>
                        <option value="stress_relief" ${userData.goal === 'stress_relief' ? 'selected' : ''}>Stress Relief</option>
                    </select>
                </div>
                <div class="form-actions" style="display:flex;gap:1rem;margin-top:1.5rem;">
                    <button type="button" class="btn-cancel" onclick="document.getElementById('editModal').remove()" style="flex:1;padding:0.8rem;background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:14px;color:var(--text-primary);font-size:1rem;cursor:pointer;">Cancel</button>
                    <button type="submit" class="btn-save" style="flex:2;padding:0.8rem;background:var(--gradient-1);border:none;border-radius:14px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer;">Save Changes</button>
                </div>
            </form>
        </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('editForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('editName').value;
        const weight = parseFloat(document.getElementById('editWeight').value);
        const height = parseFloat(document.getElementById('editHeight').value);
        const goal = document.getElementById('editGoal').value;
        if (!name || !weight || !height) { showToast('⚠️ Please fill all fields'); return; }
        const updated = { ...userData, name, weight, height, goal };
        localStorage.setItem('userData', JSON.stringify(updated));
        const recs = generateRecommendations(updated);
        displayResults(recs, updated);
        updateDashboard(updated, recs);
        updateCharts(updated);
        updateAchievements(updated, recs);
        document.getElementById('editModal').remove();
        showToast('✅ Updated successfully!');
    });
}

// ============================================
// DELETE DATA
// ============================================
function deleteData(field) {
    if (!confirm(`Delete ${field} data?`)) return;
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    if (field === 'weight') { delete userData.weight; showToast('🗑️ Weight deleted'); }
    else if (field === 'bmi') { delete userData.height; delete userData.weight; showToast('🗑️ BMI deleted'); }
    else if (field === 'calories') { delete userData.goal; showToast('🗑️ Calories deleted'); }
    else if (field === 'streak') { localStorage.removeItem('streak'); localStorage.removeItem('lastLogin'); showToast('🗑️ Streak reset'); }
    localStorage.setItem('userData', JSON.stringify(userData));
    if (userData.name && userData.weight && userData.height) {
        const recs = generateRecommendations(userData);
        updateDashboard(userData, recs);
        updateCharts(userData);
        updateAchievements(userData, recs);
    } else {
        const dashWeight = document.getElementById('dashWeight');
        const dashBMI = document.getElementById('dashBMI');
        const dashBMICategory = document.getElementById('dashBMICategory');
        const dashCalories = document.getElementById('dashCalories');
        if (dashWeight) dashWeight.textContent = '-- kg';
        if (dashBMI) dashBMI.textContent = '--';
        if (dashBMICategory) dashBMICategory.textContent = 'Not calculated';
        if (dashCalories) dashCalories.textContent = '-- kcal';
    }
}

// ============================================
// JOURNAL
// ============================================
let selectedMood = '😊';

function selectMood(mood) {
    selectedMood = mood;
    const moodDisplay = document.getElementById('selectedMood');
    if (moodDisplay) moodDisplay.textContent = mood;
    document.querySelectorAll('.mood-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.mood === mood);
    });
}

function saveJournal() {
    const entry = document.getElementById('journalEntry');
    if (!entry) return;
    if (!entry.value) { showToast('⚠️ Write something!'); return; }
    
    const data = { 
        id: Date.now(), 
        date: new Date().toLocaleDateString(), 
        time: new Date().toLocaleTimeString(), 
        mood: selectedMood, 
        entry: entry.value 
    };
    let entries = JSON.parse(localStorage.getItem('journalEntries') || '[]');
    entries.unshift(data);
    localStorage.setItem('journalEntries', JSON.stringify(entries));
    entry.value = '';
    loadJournalEntries();
    showToast('✅ Journal saved!');
}

function deleteJournalEntry(id) {
    if (!confirm('Delete entry?')) return;
    let entries = JSON.parse(localStorage.getItem('journalEntries') || '[]');
    entries = entries.filter(e => e.id !== id);
    localStorage.setItem('journalEntries', JSON.stringify(entries));
    loadJournalEntries();
    showToast('🗑️ Entry deleted');
}

function editJournalEntry(id) {
    let entries = JSON.parse(localStorage.getItem('journalEntries') || '[]');
    const entry = entries.find(e => e.id === id);
    if (!entry) return;
    const newText = prompt('Edit entry:', entry.entry);
    if (newText !== null && newText.trim()) {
        entry.entry = newText.trim();
        localStorage.setItem('journalEntries', JSON.stringify(entries));
        loadJournalEntries();
        showToast('✅ Entry updated');
    }
}

function loadJournalEntries() {
    const entries = JSON.parse(localStorage.getItem('journalEntries') || '[]');
    const container = document.getElementById('journalEntries');
    if (!container) return;
    if (!entries.length) {
        container.innerHTML = '<p style="text-align:center;color:var(--text-secondary);padding:2rem;">📝 No entries yet</p>';
        return;
    }
    container.innerHTML = entries.map(e => `
        <div class="journal-entry-item">
            <div class="entry-actions">
                <button class="edit-journal-btn" onclick="editJournalEntry(${e.id})"><i class="fas fa-pen"></i></button>
                <button class="delete-journal-btn" onclick="deleteJournalEntry(${e.id})"><i class="fas fa-trash"></i></button>
            </div>
            <div class="entry-meta"><span class="date">${e.date} at ${e.time}</span><span style="font-size:1.5rem;">${e.mood}</span></div>
            <div class="entry-text">${e.entry}</div>
        </div>
    `).join('');
}

const journalDate = document.getElementById('journalDate');
if (journalDate) journalDate.textContent = new Date().toLocaleDateString();
loadJournalEntries();

// ============================================
// REMINDERS
// ============================================
function toggleReminder(el) {
    el.classList.toggle('active');
    const label = el.closest('.reminder-item').querySelector('.reminder-info span:first-child');
    if (label) {
        showToast(`🔔 ${label.textContent}: ${el.classList.contains('active') ? 'enabled ✅' : 'disabled ❌'}`);
    }
}

// ============================================
// INIT - LOAD SAVED DATA
// ============================================
const savedUser = localStorage.getItem('userData');
if (savedUser) {
    try {
        const user = JSON.parse(savedUser);
        const data = generateRecommendations(user);
        updateDashboard(user, data);
        updateCharts(user);
        updateAchievements(user, data);
        const sections = ['dashboard', 'charts', 'journal', 'reminders', 'achievements'];
        sections.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.add('show');
        });
    } catch(e) {
        console.error('Error loading saved data:', e);
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAuth();
        const modal = document.getElementById('editModal');
        if (modal) modal.remove();
    }
});

console.log('🧘 Yoga Diet with Manasi - Ultimate Edition loaded!');
console.log('✨ Features:');
console.log('  ✅ Brand: Yoga Diet with Manasi');
console.log('  ✅ Dark/Light Theme Toggle');
console.log('  ✅ User Auth + Forgot Password');
console.log('  ✅ Personalized Assessment');
console.log('  ✅ Dashboard with Edit/Delete');
console.log('  ✅ Charts & Analytics');
console.log('  ✅ Journal with Edit/Delete');
console.log('  ✅ Achievements System');
console.log('  ✅ Smart Reminders');
console.log('  ✅ Toast Notifications');
console.log('  ✅ AI-Powered Badge Clickable');
console.log('  ✅ Data Persistence');
console.log('  ✅ Fully Responsive');